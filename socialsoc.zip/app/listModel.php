<?php

namespace SocialSoc;

use Illuminate\Database\Eloquent\Model;

class listModel extends Model
{
    //
}
